package com.example.moviedatabaserapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.moviedatabaserapp.Movie;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MovieAdapter movieAdapter;
    private MovieDatabase movieDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.movie_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize Room database
        movieDatabase = Room.databaseBuilder(getApplicationContext(), MovieDatabase.class, "movie_database").build();

        // Fetch movies and set up adapter
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<Movie> movies = movieDatabase.movieDao().getAllMovies();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        movieAdapter = new MovieAdapter(movies);
                        recyclerView.setAdapter(movieAdapter);
                    }
                });
            }
        }).start();
    }
}
