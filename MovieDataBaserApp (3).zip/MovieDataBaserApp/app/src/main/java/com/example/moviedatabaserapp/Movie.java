package com.example.moviedatabaserapp;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "movies")
public class Movie {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;
    private String studio;
    private String posterUrl;
    private float rating;

    // Constructor
    public Movie(String title, String studio, String posterUrl, float rating) {
        this.title = title;
        this.studio = studio;
        this.posterUrl = posterUrl;
        this.rating = rating;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getStudio() { return studio; }
    public void setStudio(String studio) { this.studio = studio; }
    public String getPosterUrl() { return posterUrl; }
    public void setPosterUrl(String posterUrl) { this.posterUrl = posterUrl; }
    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }
}
