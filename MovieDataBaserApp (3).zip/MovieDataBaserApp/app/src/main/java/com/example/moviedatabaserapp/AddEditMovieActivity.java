package com.example.moviedatabaserapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.moviedatabaserapp.Movie;
import com.example.moviedatabaserapp.MovieDatabase;
import com.example.moviedatabaserapp.MovieDao;

public class AddEditMovieActivity extends AppCompatActivity {

    private EditText titleEditText, studioEditText, posterUrlEditText, ratingEditText;
    private Button saveButton, cancelButton;
    private MovieDao movieDao;
    private MovieDatabase movieDatabase;
    private Movie movie; // Holds the movie if editing an existing one

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_movie);

        // Initialize the EditTexts
        titleEditText = findViewById(R.id.editTextTitle);
        studioEditText = findViewById(R.id.editTextStudio);
        posterUrlEditText = findViewById(R.id.editTextPosterUrl);
        ratingEditText = findViewById(R.id.editTextRating);

        // Initialize the Buttons
        saveButton = findViewById(R.id.buttonSave);
        cancelButton = findViewById(R.id.buttonCancel);

        // Initialize the database and DAO
        movieDatabase = DatabaseClient.getInstance(this);
        movieDao = movieDatabase.movieDao();

        // Get the movie ID passed from the previous activity (for editing)
        int movieId = getIntent().getIntExtra("MOVIE_ID", -1);

        if (movieId != -1) {
            // Fetch the movie from the database for editing
            movie = movieDao.getMovieById(movieId); // Fetch movie by ID
            if (movie != null) {
                populateFields(movie); // Populate the fields with movie details
                saveButton.setText("Update"); // Change button text to "Update" for editing
            }
        } else {
            saveButton.setText("Add"); // Change button text to "Add" for adding a new movie
        }

        // Set listeners for Save and Cancel buttons
        saveButton.setOnClickListener(v -> saveMovie());
        cancelButton.setOnClickListener(v -> finish());
    }

    private void populateFields(Movie movie) {
        titleEditText.setText(movie.getTitle());
        studioEditText.setText(movie.getStudio());
        posterUrlEditText.setText(movie.getPosterUrl());
        ratingEditText.setText(String.valueOf(movie.getRating()));
    }

    private void saveMovie() {
        // Collect the data from the input fields
        String title = titleEditText.getText().toString();
        String studio = studioEditText.getText().toString();
        String posterUrl = posterUrlEditText.getText().toString();
        float rating;

        try {
            rating = Float.parseFloat(ratingEditText.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid rating", Toast.LENGTH_SHORT).show();
            return;
        }

        if (movie == null) {
            // Creating a new movie
            movie = new Movie(title, studio, posterUrl, rating);
            movieDao.insertMovie(movie);
            Toast.makeText(this, "Movie added", Toast.LENGTH_SHORT).show();
        } else {
            // Updating an existing movie
            movie.setTitle(title);
            movie.setStudio(studio);
            movie.setPosterUrl(posterUrl);
            movie.setRating(rating);
            movieDao.updateMovie(movie);
            Toast.makeText(this, "Movie updated", Toast.LENGTH_SHORT).show();
        }

        // Close activity and return to the main list
        finish();
    }
}